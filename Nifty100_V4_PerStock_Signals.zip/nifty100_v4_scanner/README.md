# NIFTY 100 — Pine Trade Engine V4 Signal Scanner

This project watches an editable list of NIFTY 100 NSE cash equities using Upstox's market-data API and emits **only confirmed LONG ENTRY / SHORT ENTRY** events from a Python port of the signal-generating rules in the supplied `5M Trade Engine V4 - Signal Clarity` Pine Script.

It does **not** place orders. SETUP and EXIT state transitions are used internally to preserve the engine's one-active-trade state, but they are not notified.

## What it does

- Reads symbols from `nifty100_symbols.txt` (list snapshot dated 21 Oct 2026; update after index changes).
- Resolves each symbol to the current `NSE_EQ` instrument key using Upstox's daily NSE instrument master.
- Offers two modes: **LIVE DATA** and **PAST DATA**.
- LIVE DATA silently warms the engine with recent 3-minute candles, then subscribes to Upstox Market Data Feed V3 in `full` mode. It prints nothing until a new confirmed entry signal occurs.
- LIVE DATA builds 3-minute bars from consecutive closed `I1` one-minute OHLC snapshots, aligned to the NSE session open (09:15 IST).
- PAST DATA asks for a date (`YYYY-MM-DD`), replays enough preceding data to initialize the indicators and state machine, and prints only the entry signals found on the selected date.
- Both modes output only entry rows in the format `STOCK | SIGNAL #N | SIGNAL TYPE | TIME (IST) | ENTRY ₹PRICE`. The number is the count for that individual stock on that trading day, not a shared global serial. Diagnostics are written to `scanner.log`; live entries, per-stock signal numbers and entry reference prices are saved to `entry_signals.csv` and can optionally be sent through Telegram.
- LIVE DATA stays connected while the script runs. The Upstox reconnect budget is set very high. The main connection loop re-arms the budget and reconnects if the SDK reports `autoReconnectStopped` or the blocking connection call returns. Press `Ctrl+C` to stop the program.

## Requirements

- Windows, macOS or Linux with Python 3.10+
- An Upstox developer app and a valid Upstox API access token
- Internet connection during market hours

Upstox documents its V3 intraday/historical candle APIs, market-data feed and instrument master here:

- https://upstox.com/developer/api-documentation/v3/get-intra-day-candle-data/
- https://upstox.com/developer/api-documentation/v3/get-historical-candle-data/
- https://upstox.com/developer/api-documentation/v3/get-market-data-feed/
- https://upstox.com/developer/api-documentation/instruments/

## Setup on Windows

1. Install Python 3.10 or newer.
2. Extract this folder somewhere stable, e.g. `C:\Trading\nifty100_v4_scanner`.
3. Open Command Prompt in that folder and run:

   ```bat
   python -m venv .venv
   .venv\Scripts\activate
   python -m pip install --upgrade pip
   pip install -r requirements.txt
   ```

4. Copy `.env.example` to `.env` and add your Upstox access token:

   ```env
   UPSTOX_ACCESS_TOKEN=your_current_access_token
   ```

   Do not upload `.env`, share the access token, or commit it to a public repository. Upstox tokens can expire; use the current token issued for your developer app.

5. Start the script:

   ```bat
   python scanner.py
   ```

   Select `1` for **LIVE DATA** or `2` for **PAST DATA**. For past mode, enter the date as `YYYY-MM-DD`.

   You can also select a mode directly from Command Prompt:

   ```bat
   python scanner.py --mode live
   python scanner.py --mode past --date 2026-10-23
   ```

   Run LIVE DATA before 09:15 IST when possible, so the scanner is ready to process the opening candles. During warm-up the terminal remains quiet and historical signals are never emitted. If you start at 10:00 IST, it will not replay or notify entries from before startup; it will wait for fresh confirmed entries from that point onwards. Example live output: `HAL | SIGNAL #2 | SHORT ENTRY | 12:03 | ENTRY ₹4,808.00`. Each stock is numbered independently for the current trading day. Warm-up silently counts signals already generated earlier that day, so if HAL had a LONG entry before you started the scanner, a later SHORT entry may be identified as `SIGNAL #2` without replaying the old LONG alert. Each stock's counter resets on a new trading day. A row's time is the signal candle's chart timestamp; because the script waits for candle confirmation, the signal is only known once that 3-minute candle has closed.

The scanner will stop rather than return an incomplete scan if it cannot resolve the configured universe or if a stock's required history request fails. Diagnostics are recorded in `scanner.log`.

## Optional Telegram alerts

To receive notifications when the scanner is running in another window, create a Telegram bot and get your chat ID, then add both values to `.env`:

```env
TELEGRAM_BOT_TOKEN=your_bot_token
TELEGRAM_CHAT_ID=your_chat_id
```

Restart the scanner after changing `.env`. Never post the bot token publicly.

## Configuration

- `WARMUP_CALENDAR_DAYS=20`: calendar days of 3-minute data requested per stock (must remain under Upstox's 1-month request range for 1–15 minute intervals).
- `HISTORICAL_WORKERS=5`: concurrent warm-up requests; keep conservative to avoid rate limits.
- `LOG_LEVEL=INFO`: diagnostic messages are written to `scanner.log`; the normal terminal remains reserved for signal rows. The WebSocket reconnect budget is set extremely high, with a supervisor fallback if the SDK reports that auto-reconnect has stopped.
- `nifty100_symbols.txt`: one NSE trading symbol per line.

The V4 strategy parameters currently use the source script's defaults: ATR 14, EMA 21, swing sensitivity 3, structure lookback 12, impulse threshold 1.25 ATR, EMA extension 1.5 ATR, short/long impulse windows 3/8 bars, pullback 0.30–2.00 ATR, setup duration 15 bars, confirmation body 0.15 ATR, structure buffer 0.10 ATR, stop buffer 0.15 ATR, targets 1R/2R, and structural trailing stop enabled.

## Important implementation caveats

This is a Python port, not code executed by TradingView. It matches the visible V4 signal/state rules, but exact signal parity is **not yet proven**. Specifically:

1. TradingView and Upstox may differ in source OHLC data and candle construction.
2. EMA initialization and pivot tie handling can differ at edge cases.
3. Live aggregation uses Upstox's `I1` OHLC snapshots. Incomplete 3-minute groups (e.g. connection begins mid-group or one-minute data is missing) are skipped instead of filled with synthetic candles.
4. Start the scanner before market open to reduce the risk of missing the first live 3-minute candle. Do not assume historical warm-up will alert on a signal that formed before the scanner started; historical signals are intentionally suppressed.
5. Your Pine source's title says “5M”, but it can be attached to other timeframes. This project defaults to the 3-minute timeframe shown in your screenshots. Use the same timeframe in TradingView when comparing results.
6. The Pine script's visible VWAP line is visual only in this V4 source; it is not part of the entry-condition logic.

Before treating any alert as dependable, compare a few known entry bars from TradingView against the same dates/times in the scanner log and correct any parity differences. This does not change your workflow: the tool only finds signals; you perform your own analysis before any trade.

## Output

- Terminal / optional Telegram output only for `LONG ENTRY` or `SHORT ENTRY`, formatted as `#NNN | STOCK | SIGNAL | TIME (IST) | ENTRY ₹PRICE`
- `ENTRY ₹PRICE` is the signal candle close used by the V4 rules as the entry reference; it is not a guaranteed fill price. The alert arrives after the three-minute candle is confirmed, so market price may have moved.
- `entry_signals.csv` with per-stock signal number, stock, signal, time and entry reference price
- `scanner.log` for diagnostics (warm-up progress is not printed to the terminal)
- `nse_instruments_cache.json`, a cached Upstox instrument master that refreshes after 12 hours

The displayed entry reference price is the close of the confirmed signal candle, **not a guaranteed execution price**. Since alerts are only generated after a candle closes, the latest traded price may differ. Stops and targets are reference levels from the indicator, not broker orders.

Signal numbering increments separately for each stock during the trading day. LIVE warm-up silently counts that stock's earlier same-day entries, but never emits historical alerts; PAST mode numbers the selected date's entries independently for each stock, starting at `SIGNAL #1` per stock. The running scanner never submits an order. The auto-reconnect limit is intentionally set extremely high, and the main connection loop opens the feed again if the SDK gives up or the blocking connect call returns. This cannot overcome an expired token, extended provider outage, missing internet, or a powered-off computer; check `scanner.log` if the feed stops. Press `Ctrl+C` to stop it.
