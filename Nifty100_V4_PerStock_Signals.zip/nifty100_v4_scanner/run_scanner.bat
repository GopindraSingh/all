@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Python virtual environment not found.
  echo First run the setup commands in README.md.
  pause
  exit /b 1
)
call ".venv\Scripts\activate.bat"
python scanner.py
pause
