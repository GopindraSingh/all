"""Python port of the signal-generating state machine in 5M Trade Engine V4.

Only LONG ENTRY and SHORT ENTRY events are returned. SETUP and EXIT events are
used internally to preserve the Pine state machine, but are never emitted.

Notes on matching TradingView:
- Intended for confirmed 3-minute candles (the scanner's default timeframe).
- EMA is initialized from the first loaded close; ATR uses Wilder/RMA seeding.
- Pivot tie handling is an explicit approximation of Pine pivothigh/pivotlow.
- Compare against TradingView before relying on the output. Feed and indicator
  implementation differences can change individual signals.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, date
from typing import Optional, Literal
import math


@dataclass(frozen=True)
class Candle:
    timestamp: datetime  # candle start time, timezone-aware preferred
    open: float
    high: float
    low: float
    close: float
    volume: float = 0.0


@dataclass(frozen=True)
class EntrySignal:
    symbol: str
    direction: Literal["LONG ENTRY", "SHORT ENTRY"]
    candle_time: datetime
    signal_close: float
    stop: float
    target1: float
    target2: float


@dataclass
class Settings:
    atr_length: int = 14
    ema_length: int = 21
    swing_length: int = 3
    structure_lookback: int = 12
    minimum_impulse_atr: float = 1.25
    extension_atr: float = 1.50
    short_impulse_bars: int = 3
    long_impulse_bars: int = 8
    minimum_pullback_atr: float = 0.30
    maximum_pullback_atr: float = 2.00
    maximum_setup_bars: int = 15
    confirmation_body_atr: float = 0.15
    weakening_score_required: int = 2
    reversal_score_required: int = 3
    structure_break_atr: float = 0.10
    stop_buffer_atr: float = 0.15
    target1_r: float = 1.0
    target2_r: float = 2.0
    use_trailing_stop: bool = True
    fallback_tick_size: float = 0.05


WAIT, EXTENDED, PULLBACK, ACTIVE, WEAKENING, REVERSAL = range(6)


class V4SignalEngine:
    """Sequential per-symbol state engine; call once per confirmed candle."""

    def __init__(self, symbol: str, settings: Optional[Settings] = None):
        self.symbol = symbol
        self.cfg = settings or Settings()
        self.bars: list[Candle] = []
        self.true_ranges: list[float] = []
        self.ema: Optional[float] = None
        self.atr: Optional[float] = None
        self.bar_index = -1
        self.session_date: Optional[date] = None
        self.last_processed_timestamp: Optional[datetime] = None

        self.state = WAIT
        self.direction = 0
        self.watch_start_bar: Optional[int] = None
        self.setup_start_bar: Optional[int] = None
        self.entry_bar: Optional[int] = None
        self.impulse_origin: Optional[float] = None
        self.impulse_extreme: Optional[float] = None
        self.pullback_high: Optional[float] = None
        self.pullback_low: Optional[float] = None
        self.entry_price: Optional[float] = None
        self.initial_stop: Optional[float] = None
        self.active_stop: Optional[float] = None
        self.risk_per_share: Optional[float] = None
        self.target1: Optional[float] = None
        self.target2: Optional[float] = None
        self.thesis_high: Optional[float] = None
        self.thesis_low: Optional[float] = None
        self.target1_hit = False
        self.target2_hit = False
        self.last_swing_high: Optional[float] = None
        self.previous_swing_high: Optional[float] = None
        self.last_swing_low: Optional[float] = None
        self.previous_swing_low: Optional[float] = None

    def _reset_for_session(self) -> None:
        # Mirrors the Pine daily reset. Confirmed swing references are NOT reset.
        self.state = WAIT
        self.direction = 0
        self.watch_start_bar = None
        self.setup_start_bar = None
        self.entry_bar = None
        self.impulse_origin = None
        self.impulse_extreme = None
        self.pullback_high = None
        self.pullback_low = None
        self.entry_price = None
        self.initial_stop = None
        self.active_stop = None
        self.risk_per_share = None
        self.target1 = None
        self.target2 = None
        self.thesis_high = None
        self.thesis_low = None
        self.target1_hit = False
        self.target2_hit = False

    def _clear_to_wait(self) -> None:
        self.state = WAIT
        self.direction = 0
        self.watch_start_bar = None
        self.setup_start_bar = None
        self.entry_bar = None
        self.impulse_origin = None
        self.impulse_extreme = None
        self.pullback_high = None
        self.pullback_low = None
        self.entry_price = None
        self.initial_stop = None
        self.active_stop = None
        self.risk_per_share = None
        self.target1 = None
        self.target2 = None
        self.thesis_high = None
        self.thesis_low = None
        self.target1_hit = False
        self.target2_hit = False

    @staticmethod
    def _max_or_none(values: list[float]) -> Optional[float]:
        return max(values) if values else None

    @staticmethod
    def _min_or_none(values: list[float]) -> Optional[float]:
        return min(values) if values else None

    def _update_indicators(self, candle: Candle) -> tuple[float, float, float]:
        prev_close = self.bars[-1].close if self.bars else None
        if prev_close is None:
            tr = candle.high - candle.low
        else:
            tr = max(
                candle.high - candle.low,
                abs(candle.high - prev_close),
                abs(candle.low - prev_close),
            )
        self.true_ranges.append(tr)

        alpha = 2.0 / (self.cfg.ema_length + 1.0)
        self.ema = candle.close if self.ema is None else alpha * candle.close + (1.0 - alpha) * self.ema

        if self.atr is None:
            if len(self.true_ranges) >= self.cfg.atr_length:
                # First valid Wilder RMA = SMA of the first ATR-length TR values.
                self.atr = sum(self.true_ranges[: self.cfg.atr_length]) / self.cfg.atr_length
        else:
            self.atr = ((self.atr * (self.cfg.atr_length - 1)) + tr) / self.cfg.atr_length

        self.bars.append(candle)
        self.bar_index += 1
        safe_atr = max(self.atr if self.atr is not None else self.cfg.fallback_tick_size,
                       self.cfg.fallback_tick_size)
        body_atr = abs(candle.close - candle.open) / safe_atr
        return safe_atr, body_atr, candle.close - self.bars[-4].close if len(self.bars) >= 4 else 0.0

    def _update_confirmed_pivots(self) -> None:
        width = self.cfg.swing_length
        idx = len(self.bars) - 1
        pivot_idx = idx - width
        if pivot_idx - width < 0 or pivot_idx + width >= len(self.bars):
            return
        window = self.bars[pivot_idx - width : pivot_idx + width + 1]
        candidate = window[width]
        left, right = window[:width], window[width + 1 :]
        # Local maximum/minimum with ties resolved toward the most recent equal pivot.
        if all(candidate.high >= b.high for b in left) and all(candidate.high > b.high for b in right):
            self.previous_swing_high = self.last_swing_high
            self.last_swing_high = candidate.high
        if all(candidate.low <= b.low for b in left) and all(candidate.low < b.low for b in right):
            self.previous_swing_low = self.last_swing_low
            self.last_swing_low = candidate.low

    def _entry_signal(self, direction: str, candle: Candle) -> EntrySignal:
        assert self.active_stop is not None and self.target1 is not None and self.target2 is not None
        return EntrySignal(
            symbol=self.symbol,
            direction=direction,  # type: ignore[arg-type]
            candle_time=candle.timestamp,
            signal_close=candle.close,
            stop=self.active_stop,
            target1=self.target1,
            target2=self.target2,
        )

    def process(self, candle: Candle) -> Optional[EntrySignal]:
        """Process a single CLOSED candle. Returns entry signals only."""
        if self.last_processed_timestamp is not None:
            if candle.timestamp <= self.last_processed_timestamp:
                return None  # avoids duplicate / out-of-order candles
        self.last_processed_timestamp = candle.timestamp

        safe_atr, body_atr, momentum3 = self._update_indicators(candle)
        day = candle.timestamp.date()
        if self.session_date is None or day != self.session_date:
            self.session_date = day
            self._reset_for_session()

        self._update_confirmed_pivots()
        c = self.cfg
        bars = self.bars
        close, high, low, op = candle.close, candle.high, candle.low, candle.open
        ema = self.ema if self.ema is not None else close

        highs = [b.high for b in bars[-c.structure_lookback :]]
        lows = [b.low for b in bars[-c.structure_lookback :]]
        prior_struct = bars[-(c.structure_lookback + 1) : -1]
        previous_recent_high = self._max_or_none([b.high for b in prior_struct])
        previous_recent_low = self._min_or_none([b.low for b in prior_struct])
        recent_high = self._max_or_none(highs)
        recent_low = self._min_or_none(lows)
        bullish_environment = close > ema and recent_high is not None and previous_recent_high is not None and recent_high >= previous_recent_high
        bearish_environment = close < ema and recent_low is not None and previous_recent_low is not None and recent_low <= previous_recent_low

        short_bull_move = close - bars[-1 - c.short_impulse_bars].close if len(bars) > c.short_impulse_bars else 0.0
        short_bear_move = bars[-1 - c.short_impulse_bars].close - close if len(bars) > c.short_impulse_bars else 0.0
        long_bull_move = close - bars[-1 - c.long_impulse_bars].close if len(bars) > c.long_impulse_bars else 0.0
        long_bear_move = bars[-1 - c.long_impulse_bars].close - close if len(bars) > c.long_impulse_bars else 0.0
        short_bull_atr = short_bull_move / safe_atr
        short_bear_atr = short_bear_move / safe_atr
        long_bull_atr = long_bull_move / safe_atr
        long_bear_atr = long_bear_move / safe_atr
        bullish_impulse = bullish_environment and momentum3 > 0 and (short_bull_atr >= c.minimum_impulse_atr or long_bull_atr >= c.minimum_impulse_atr)
        bearish_impulse = bearish_environment and momentum3 < 0 and (short_bear_atr >= c.minimum_impulse_atr or long_bear_atr >= c.minimum_impulse_atr)
        ema_distance_atr = (close - ema) / safe_atr
        bullish_extension = bullish_impulse and ema_distance_atr >= c.extension_atr
        bearish_extension = bearish_impulse and ema_distance_atr <= -c.extension_atr

        signal: Optional[EntrySignal] = None

        if self.state == WAIT:
            if bullish_extension:
                self.state, self.direction = EXTENDED, 1
                self.watch_start_bar = self.bar_index
                self.setup_start_bar = None
                self.entry_bar = None
                # Preserved from V4 verbatim: origin uses the long impulse window.
                self.impulse_origin = close - long_bull_move
                self.impulse_extreme = high
                self.pullback_high = self.pullback_low = None
            elif bearish_extension:
                self.state, self.direction = EXTENDED, -1
                self.watch_start_bar = self.bar_index
                self.setup_start_bar = None
                self.entry_bar = None
                # Preserved from V4 verbatim: origin uses the long impulse window.
                self.impulse_origin = close + long_bear_move
                self.impulse_extreme = low
                self.pullback_high = self.pullback_low = None

        elif self.state == EXTENDED:
            expired = self.watch_start_bar is not None and self.bar_index - self.watch_start_bar > c.maximum_setup_bars
            if expired:
                self._clear_to_wait()
            elif self.direction == 1:
                self.impulse_extreme = max(self.impulse_extreme if self.impulse_extreme is not None else high, high)
                distance_atr = (self.impulse_extreme - low) / safe_atr
                structure_healthy = self.last_swing_low is None or close > self.last_swing_low - c.structure_break_atr * safe_atr
                if c.minimum_pullback_atr <= distance_atr <= c.maximum_pullback_atr and structure_healthy:
                    self.state = PULLBACK
                    self.setup_start_bar = self.bar_index
                    self.pullback_high, self.pullback_low = high, low
                elif not structure_healthy:
                    self._clear_to_wait()
            elif self.direction == -1:
                self.impulse_extreme = min(self.impulse_extreme if self.impulse_extreme is not None else low, low)
                distance_atr = (high - self.impulse_extreme) / safe_atr
                structure_healthy = self.last_swing_high is None or close < self.last_swing_high + c.structure_break_atr * safe_atr
                if c.minimum_pullback_atr <= distance_atr <= c.maximum_pullback_atr and structure_healthy:
                    self.state = PULLBACK
                    self.setup_start_bar = self.bar_index
                    self.pullback_high, self.pullback_low = high, low
                elif not structure_healthy:
                    self._clear_to_wait()

        elif self.state == PULLBACK:
            expired = self.setup_start_bar is not None and self.bar_index - self.setup_start_bar > c.maximum_setup_bars
            if expired:
                self._clear_to_wait()
            elif self.direction == 1:
                prev_ph = self.pullback_high if self.pullback_high is not None else high
                prev_pl = self.pullback_low if self.pullback_low is not None else low
                healthy = close > (self.impulse_origin if self.impulse_origin is not None else -math.inf) and (self.last_swing_low is None or close > self.last_swing_low - c.structure_break_atr * safe_atr)
                continuation = close > prev_ph and close > op and body_atr >= c.confirmation_body_atr and close > ema
                if not healthy:
                    self._clear_to_wait()
                elif continuation:
                    structural_stop = prev_pl
                    if self.last_swing_low is not None:
                        structural_stop = min(structural_stop, self.last_swing_low)
                    proposed_stop = structural_stop - c.stop_buffer_atr * safe_atr
                    if proposed_stop < close:
                        self.entry_price = close
                        self.initial_stop = self.active_stop = proposed_stop
                        self.risk_per_share = close - proposed_stop
                        self.target1 = close + self.risk_per_share * c.target1_r
                        self.target2 = close + self.risk_per_share * c.target2_r
                        self.thesis_high, self.thesis_low = high, prev_pl
                        self.entry_bar = self.bar_index
                        self.target1_hit = self.target2_hit = False
                        self.state = ACTIVE
                        signal = self._entry_signal("LONG ENTRY", candle)
                    else:
                        self.pullback_high = max(prev_ph, high)
                        self.pullback_low = min(prev_pl, low)
                else:
                    self.pullback_high = max(prev_ph, high)
                    self.pullback_low = min(prev_pl, low)
            elif self.direction == -1:
                prev_ph = self.pullback_high if self.pullback_high is not None else high
                prev_pl = self.pullback_low if self.pullback_low is not None else low
                healthy = close < (self.impulse_origin if self.impulse_origin is not None else math.inf) and (self.last_swing_high is None or close < self.last_swing_high + c.structure_break_atr * safe_atr)
                continuation = close < prev_pl and close < op and body_atr >= c.confirmation_body_atr and close < ema
                if not healthy:
                    self._clear_to_wait()
                elif continuation:
                    structural_stop = prev_ph
                    if self.last_swing_high is not None:
                        structural_stop = max(structural_stop, self.last_swing_high)
                    proposed_stop = structural_stop + c.stop_buffer_atr * safe_atr
                    if proposed_stop > close:
                        self.entry_price = close
                        self.initial_stop = self.active_stop = proposed_stop
                        self.risk_per_share = proposed_stop - close
                        self.target1 = close - self.risk_per_share * c.target1_r
                        self.target2 = close - self.risk_per_share * c.target2_r
                        self.thesis_high, self.thesis_low = prev_ph, low
                        self.entry_bar = self.bar_index
                        self.target1_hit = self.target2_hit = False
                        self.state = ACTIVE
                        signal = self._entry_signal("SHORT ENTRY", candle)
                    else:
                        self.pullback_high = max(prev_ph, high)
                        self.pullback_low = min(prev_pl, low)
                else:
                    self.pullback_high = max(prev_ph, high)
                    self.pullback_low = min(prev_pl, low)

        elif self.state in (ACTIVE, WEAKENING, REVERSAL):
            if self.direction == 1:
                self.thesis_high = max(self.thesis_high if self.thesis_high is not None else high, high)
                if c.use_trailing_stop and self.last_swing_low is not None:
                    candidate = self.last_swing_low - c.stop_buffer_atr * safe_atr
                    self.active_stop = candidate if self.active_stop is None else max(self.active_stop, candidate)
                if not self.target1_hit and self.target1 is not None and high >= self.target1:
                    self.target1_hit = True
                if not self.target2_hit and self.target2 is not None and high >= self.target2:
                    self.target2_hit = True
                ema_failure = close < ema
                momentum_failure = momentum3 < 0
                prior_highs = [b.high for b in bars[-6:-1]]
                recent_high_before = self._max_or_none(prior_highs)
                continuation_failure = recent_high_before is not None and high <= recent_high_before and close < recent_high_before
                structure_failure = self.thesis_low is not None and close < self.thesis_low - c.structure_break_atr * safe_atr
                evidence = sum((ema_failure, momentum_failure, continuation_failure, structure_failure))
                weakening = evidence >= c.weakening_score_required
                reversal = evidence >= c.reversal_score_required
                stop_hit = self.active_stop is not None and close <= self.active_stop
                thesis_broken = structure_failure and momentum_failure
                if thesis_broken or stop_hit:
                    self._clear_to_wait()
                elif reversal:
                    self.state = REVERSAL
                elif weakening:
                    self.state = WEAKENING
                else:
                    self.state = ACTIVE

            elif self.direction == -1:
                self.thesis_low = min(self.thesis_low if self.thesis_low is not None else low, low)
                if c.use_trailing_stop and self.last_swing_high is not None:
                    candidate = self.last_swing_high + c.stop_buffer_atr * safe_atr
                    self.active_stop = candidate if self.active_stop is None else min(self.active_stop, candidate)
                if not self.target1_hit and self.target1 is not None and low <= self.target1:
                    self.target1_hit = True
                if not self.target2_hit and self.target2 is not None and low <= self.target2:
                    self.target2_hit = True
                ema_failure = close > ema
                momentum_failure = momentum3 > 0
                prior_lows = [b.low for b in bars[-6:-1]]
                recent_low_before = self._min_or_none(prior_lows)
                continuation_failure = recent_low_before is not None and low >= recent_low_before and close > recent_low_before
                structure_failure = self.thesis_high is not None and close > self.thesis_high + c.structure_break_atr * safe_atr
                evidence = sum((ema_failure, momentum_failure, continuation_failure, structure_failure))
                weakening = evidence >= c.weakening_score_required
                reversal = evidence >= c.reversal_score_required
                stop_hit = self.active_stop is not None and close >= self.active_stop
                thesis_broken = structure_failure and momentum_failure
                if thesis_broken or stop_hit:
                    self._clear_to_wait()
                elif reversal:
                    self.state = REVERSAL
                elif weakening:
                    self.state = WEAKENING
                else:
                    self.state = ACTIVE

        return signal
