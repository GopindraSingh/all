import csv
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

from scanner import AlertDispatcher, ROOT, SIGNAL_CSV_FIELDS, ThreeMinuteAggregator, format_signal_row, next_stock_signal_number, parse_trading_date, read_symbols
from strategy_v4 import Candle, EntrySignal, V4SignalEngine

IST = ZoneInfo("Asia/Kolkata")


def test_three_consecutive_minutes_produce_one_three_minute_bar():
    engine = V4SignalEngine("TEST")
    alerts = []
    agg = ThreeMinuteAggregator("TEST", engine, alerts.append)
    start = datetime(2026, 10, 1, 9, 15, tzinfo=IST)
    for i in range(3):
        close = 100 + i
        agg.on_minute_closed(Candle(start + timedelta(minutes=i), close - 0.2, close + 0.5, close - 0.5, close, 100))
    assert len(engine.bars) == 1
    bar = engine.bars[0]
    assert bar.timestamp == start
    assert bar.open == 99.8
    assert bar.high == 102.5
    assert bar.low == 99.5
    assert bar.close == 102


def test_incomplete_three_minute_group_is_skipped():
    engine = V4SignalEngine("TEST")
    alerts = []
    agg = ThreeMinuteAggregator("TEST", engine, alerts.append)
    start = datetime(2026, 10, 1, 9, 15, tzinfo=IST)
    agg.on_minute_closed(Candle(start, 100, 101, 99, 100, 100))
    agg.on_minute_closed(Candle(start + timedelta(minutes=2), 100, 101, 99, 100, 100))
    assert len(engine.bars) == 0


def test_signal_output_uses_per_stock_signal_number_and_entry_price():
    signal = EntrySignal(
        symbol="ABB",
        direction="LONG ENTRY",
        candle_time=datetime(2026, 10, 1, 9, 33, tzinfo=IST),
        signal_close=123.45,
        stop=120.0,
        target1=126.9,
        target2=130.35,
    )
    assert format_signal_row(signal, 1) == "ABB | SIGNAL #1 | LONG ENTRY | 09:33 | ENTRY ₹123.45"


def test_signal_number_increments_per_stock_not_globally():
    counters = {}
    assert next_stock_signal_number(counters, "HAL") == 1
    assert next_stock_signal_number(counters, "ABB") == 1
    assert next_stock_signal_number(counters, "HAL") == 2
    assert next_stock_signal_number(counters, "HAL") == 3
    assert next_stock_signal_number(counters, "ABB") == 2


def test_signal_output_formats_large_entry_price_with_comma():
    signal = EntrySignal(
        symbol="HAL",
        direction="SHORT ENTRY",
        candle_time=datetime(2026, 10, 1, 10, 3, tzinfo=IST),
        signal_close=4808.0,
        stop=4830.0,
        target1=4786.0,
        target2=4764.0,
    )
    assert format_signal_row(signal, 2) == "HAL | SIGNAL #2 | SHORT ENTRY | 10:03 | ENTRY ₹4,808.00"


def test_parse_past_date_format():
    assert parse_trading_date("2025-01-15").isoformat() == "2025-01-15"


def test_parse_trading_date_rejects_invalid_date_format():
    try:
        parse_trading_date("15-01-2025")
    except ValueError as exc:
        assert "YYYY-MM-DD" in str(exc)
    else:
        raise AssertionError("Invalid date format should be rejected")


def test_existing_signal_csv_migrates_global_serial_to_per_stock_numbers(tmp_path):
    path = tmp_path / "entry_signals.csv"
    path.write_text(
        "signal_no,stock,signal,time_ist,entry_reference_price_inr\n"
        "1,ABB,LONG ENTRY,2026-10-01 09:33,123.45\n"
        "2,HAL,SHORT ENTRY,2026-10-01 10:03,4808.00\n"
        "3,ABB,SHORT ENTRY,2026-10-01 11:03,122.50\n"
        "1,INFY,LONG ENTRY,2026-10-02 09:24,1520.50\n",
        encoding="utf-8",
    )
    dispatcher = AlertDispatcher.__new__(AlertDispatcher)
    dispatcher.log_path = path
    dispatcher._ensure_csv_schema()
    with path.open("r", newline="", encoding="utf-8") as file:
        reader = csv.DictReader(file)
        assert reader.fieldnames == SIGNAL_CSV_FIELDS
        rows = list(reader)
    assert len(rows) == 4
    assert [(r["stock"], r["stock_signal_no"]) for r in rows] == [
        ("ABB", "1"), ("HAL", "1"), ("ABB", "2"), ("INFY", "1")
    ]


def test_nifty100_universe_has_exactly_100_unique_symbols():
    symbols = read_symbols(ROOT / "nifty100_symbols.txt")
    assert len(symbols) == 100
    assert len(set(symbols)) == 100
