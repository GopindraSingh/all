from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

from strategy_v4 import Candle, V4SignalEngine

IST = ZoneInfo("Asia/Kolkata")


def test_duplicate_timestamp_is_ignored():
    engine = V4SignalEngine("TEST")
    t = datetime(2026, 10, 1, 9, 15, tzinfo=IST)
    candle = Candle(t, 100, 101, 99, 100.5, 1000)
    assert engine.process(candle) is None
    # Duplicate input must not append a second copy.
    assert engine.process(candle) is None
    assert len(engine.bars) == 1


def test_engine_accepts_many_closed_bars_without_exception():
    engine = V4SignalEngine("TEST")
    t = datetime(2026, 10, 1, 9, 15, tzinfo=IST)
    for i in range(180):
        close = 100 + 0.12 * i + (0.7 if (i % 7) < 4 else -0.4)
        op = close - (0.25 if i % 2 else -0.20)
        c = Candle(t + timedelta(minutes=3 * i), op, max(op, close) + 0.15, min(op, close) - 0.15, close, 10000 + i)
        engine.process(c)
    assert len(engine.bars) == 180
    assert engine.ema is not None
    assert engine.atr is not None
