"""NIFTY 50 signal scanner for the user's Pine Trade Engine V4.

- Upstox API V3 historical candles for warm-up
- Upstox MarketDataStreamerV3 full feed for live one-minute OHLC snapshots
- Aggregates closed one-minute candles into 3-minute bars aligned to 09:15 IST
- Emits only LONG ENTRY / SHORT ENTRY; no order placement
"""
from __future__ import annotations

import argparse
import csv
import gzip
import json
import logging
import os
import queue
import sys
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import asdict
from datetime import date, datetime, timedelta, time as daytime
from pathlib import Path
from typing import Any, Optional
from urllib.parse import quote
from zoneinfo import ZoneInfo

import requests
from dotenv import load_dotenv

from strategy_v4 import Candle, EntrySignal, V4SignalEngine

ROOT = Path(__file__).resolve().parent
load_dotenv(ROOT / ".env")
IST = ZoneInfo("Asia/Kolkata")
MARKET_OPEN = daytime(9, 15)
MARKET_CLOSE = daytime(15, 30)
INTERVAL_MINUTES = 3
# Effectively unbounded auto-reconnect budget; live mode should keep running
# through transient outages until the user stops the process.
RECONNECT_INTERVAL_SECONDS = 5
RECONNECT_RETRY_COUNT = 1_000_000_000
UPSTOX_INSTRUMENTS_URL = "https://assets.upstox.com/market-quote/instruments/exchange/NSE.json.gz"
UPSTOX_HISTORICAL_URL = "https://api.upstox.com/v3/historical-candle"

# Keep normal terminal output reserved for the user's requested signal rows.
# Diagnostics are written to scanner.log instead of cluttering the live console.
logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO").upper(),
    format="%(asctime)s | %(levelname)s | %(message)s",
    datefmt="%H:%M:%S",
    handlers=[logging.FileHandler(ROOT / "scanner.log", encoding="utf-8")],
    force=True,
)
log = logging.getLogger("nifty50-scanner")


def format_signal_row(signal: EntrySignal) -> str:
    """Return the only signal fields requested: stock, direction, chart time."""
    stamp = signal.candle_time.astimezone(IST).strftime("%H:%M")
    return f"{signal.symbol} | {signal.direction} | {stamp}"


def parse_trading_date(value: str) -> date:
    """Parse a strict YYYY-MM-DD date and reject future dates."""
    try:
        target = datetime.strptime(value.strip(), "%Y-%m-%d").date()
    except ValueError as exc:
        raise ValueError("Date must use YYYY-MM-DD format, e.g. 2026-10-23.") from exc
    if target > datetime.now(IST).date():
        raise ValueError("Future dates cannot be scanned. Enter today or a past date.")
    return target


def norm_symbol(value: str) -> str:
    return re.sub(r"[^A-Z0-9]", "", str(value).upper().strip())


def read_symbols(path: Path) -> list[str]:
    symbols = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.split("#", 1)[0].strip().upper()
        if line:
            symbols.append(line)
    # Keep stable order while removing accidental duplicates.
    symbols = list(dict.fromkeys(symbols))
    if not symbols:
        raise RuntimeError(f"No symbols found in {path}")
    return symbols


def object_to_plain(value: Any) -> Any:
    """Best-effort conversion of SDK/protobuf objects to nested dictionaries."""
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        return {str(k): object_to_plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [object_to_plain(v) for v in value]
    try:
        from google.protobuf.json_format import MessageToDict
        from google.protobuf.message import Message
        if isinstance(value, Message):
            return MessageToDict(value, preserving_proto_field_name=False)
    except Exception:
        pass
    if hasattr(value, "to_dict"):
        try:
            return object_to_plain(value.to_dict())
        except Exception:
            pass
    if hasattr(value, "__dict__"):
        return {k: object_to_plain(v) for k, v in vars(value).items() if not k.startswith("_")}
    return value


def getv(obj: Any, name: str, default=None):
    """Get protobuf/JSON fields in camelCase or snake_case."""
    if isinstance(obj, dict):
        if name in obj:
            return obj[name]
        snake = re.sub(r"([A-Z])", r"_\1", name).lower()
        if snake in obj:
            return obj[snake]
        camel = re.sub(r"_([a-z])", lambda m: m.group(1).upper(), name)
        if camel in obj:
            return obj[camel]
        return default
    for key in (name, re.sub(r"([A-Z])", r"_\1", name).lower()):
        if hasattr(obj, key):
            return getattr(obj, key)
    return default


def parse_timestamp(raw: Any) -> datetime:
    """Parse Upstox ISO timestamps or epoch milliseconds into IST."""
    if isinstance(raw, datetime):
        return raw.astimezone(IST) if raw.tzinfo else raw.replace(tzinfo=IST)
    if isinstance(raw, (int, float)) or (isinstance(raw, str) and raw.isdigit()):
        number = int(raw)
        if number > 10_000_000_000:
            number /= 1000
        return datetime.fromtimestamp(number, tz=IST)
    parsed = datetime.fromisoformat(str(raw).replace("Z", "+00:00"))
    return parsed.astimezone(IST) if parsed.tzinfo else parsed.replace(tzinfo=IST)


def load_instrument_master() -> dict[str, dict[str, str]]:
    """Map NSE symbols to current Upstox instrument keys from its daily master."""
    cache = ROOT / "nse_instruments_cache.json"
    data = None
    if cache.exists() and datetime.now().timestamp() - cache.stat().st_mtime < 12 * 3600:
        try:
            data = json.loads(cache.read_text(encoding="utf-8"))
        except Exception:
            data = None
    if data is None:
        log.info("Downloading Upstox NSE instrument master...")
        response = requests.get(UPSTOX_INSTRUMENTS_URL, timeout=30)
        response.raise_for_status()
        raw = response.content
        if raw[:2] == b"\x1f\x8b":
            raw = gzip.decompress(raw)
        data = json.loads(raw.decode("utf-8"))
        cache.write_text(json.dumps(data), encoding="utf-8")

    records = data if isinstance(data, list) else data.get("data", data.get("instruments", []))
    by_symbol: dict[str, dict[str, str]] = {}
    for row in records:
        if str(row.get("segment", "")) != "NSE_EQ" or str(row.get("instrument_type", "")) != "EQ":
            continue
        symbol = str(row.get("trading_symbol") or row.get("short_name") or "").upper()
        key = row.get("instrument_key")
        if symbol and key:
            by_symbol[norm_symbol(symbol)] = {
                "symbol": symbol,
                "instrument_key": str(key),
                "name": str(row.get("name", symbol)),
            }
            short_name = str(row.get("short_name") or "").upper()
            if short_name:
                by_symbol.setdefault(norm_symbol(short_name), by_symbol[norm_symbol(symbol)])
    return by_symbol


def resolve_universe(symbols: list[str], master: dict[str, dict[str, str]]) -> dict[str, dict[str, str]]:
    resolved, missing = {}, []
    for symbol in symbols:
        item = master.get(norm_symbol(symbol))
        if item is None:
            missing.append(symbol)
        else:
            resolved[symbol] = item
    if missing:
        log.warning("Symbols not resolved in today's Upstox master (%d): %s", len(missing), ", ".join(missing))
    if missing:
        raise RuntimeError(
            f"Could not resolve all configured NIFTY 50 symbols. Missing: {', '.join(missing)}. "
            "Check nifty50_symbols.txt and the Upstox instrument master; refusing to scan an incomplete universe."
        )
    log.info("Resolved all %d configured NIFTY 50 symbols.", len(resolved))
    return resolved


def fetch_history(symbol: str, item: dict[str, str], token: str, from_date: str, to_date: str) -> tuple[str, list[Candle]]:
    encoded_key = quote(item["instrument_key"], safe="")
    url = f"{UPSTOX_HISTORICAL_URL}/{encoded_key}/minutes/3/{to_date}/{from_date}"
    headers = {"Accept": "application/json", "Authorization": f"Bearer {token}"}
    last_error = None
    for attempt in range(3):
        try:
            response = requests.get(url, headers=headers, timeout=20)
            if response.status_code == 429:
                time.sleep(1.0 + attempt * 1.5)
                continue
            response.raise_for_status()
            payload = response.json()
            raw_candles = payload.get("data", {}).get("candles", [])
            candles = []
            now = datetime.now(IST)
            for raw in raw_candles:
                ts = parse_timestamp(raw[0])
                # Don't process a still-forming 3-minute historical candle during warm-up.
                if ts + timedelta(minutes=3) > now:
                    continue
                candles.append(Candle(ts, float(raw[1]), float(raw[2]), float(raw[3]), float(raw[4]), float(raw[5] or 0)))
            candles.sort(key=lambda c: c.timestamp)
            return symbol, candles
        except Exception as exc:
            last_error = exc
            time.sleep(0.5 * (attempt + 1))
    raise RuntimeError(f"History request failed for {symbol}: {last_error}")


def is_market_timestamp(ts: datetime) -> bool:
    return ts.weekday() < 5 and MARKET_OPEN <= ts.time().replace(tzinfo=None) < MARKET_CLOSE


class ThreeMinuteAggregator:
    """Aggregate exactly three complete consecutive 1-minute candles.

    Incomplete 3-minute buckets are skipped instead of fabricated, avoiding
    synthetic candles that could create misleading strategy signals.
    """
    def __init__(self, symbol: str, engine: V4SignalEngine, alert_callback):
        self.symbol = symbol
        self.engine = engine
        self.alert_callback = alert_callback
        self.current_1m: Optional[Candle] = None
        self.bucket_start: Optional[datetime] = None
        self.parts: list[Candle] = []
        self.bucket_invalid = False
        self.last_minute_ts: Optional[datetime] = None
        self.last_3m_start: Optional[datetime] = None

    @staticmethod
    def _bucket(ts: datetime) -> tuple[datetime, int]:
        anchor = ts.replace(hour=9, minute=15, second=0, microsecond=0)
        offset = int((ts - anchor).total_seconds() // 60)
        start = anchor + timedelta(minutes=(offset // 3) * 3)
        return start, offset % 3

    def on_minute_closed(self, minute: Candle) -> None:
        ts = minute.timestamp.replace(second=0, microsecond=0)
        if not is_market_timestamp(ts):
            return
        gap = 1
        if self.last_minute_ts is not None:
            gap = int((ts - self.last_minute_ts).total_seconds() // 60)
            if gap <= 0:
                return
        start, offset = self._bucket(ts)
        if self.bucket_start is None or start != self.bucket_start:
            if self.parts:
                log.debug("Discarding incomplete 3m bucket for %s at %s", self.symbol, self.bucket_start)
            self.bucket_start = start
            self.parts = []
            # If we first observe a bucket after its opening minute, it is incomplete.
            self.bucket_invalid = offset != 0
        elif gap > 1:
            # A missing minute inside this same 3-minute bucket makes it unusable.
            self.bucket_invalid = True
        self.last_minute_ts = ts
        if self.parts and (ts - self.parts[-1].timestamp).total_seconds() != 60:
            self.bucket_invalid = True
        self.parts.append(minute)
        if offset == 2:
            if len(self.parts) == 3 and not self.bucket_invalid:
                bar = Candle(
                    timestamp=self.bucket_start,
                    open=self.parts[0].open,
                    high=max(p.high for p in self.parts),
                    low=min(p.low for p in self.parts),
                    close=self.parts[-1].close,
                    volume=sum(p.volume for p in self.parts),
                )
                if self.last_3m_start is None or bar.timestamp > self.last_3m_start:
                    self.last_3m_start = bar.timestamp
                    signal = self.engine.process(bar)
                    if signal:
                        self.alert_callback(signal)
            elif len(self.parts) != 3 or self.bucket_invalid:
                log.debug("Skipping incomplete 3m candle %s for %s (%d/3 minutes)", self.bucket_start, self.symbol, len(self.parts))
            self.parts = []
            self.bucket_start = None
            self.bucket_invalid = False

    def on_live_minute_snapshot(self, snapshot: Candle) -> None:
        """Keep the latest I1 snapshot; finalize previous minute when its timestamp rolls."""
        ts = snapshot.timestamp.replace(second=0, microsecond=0)
        if self.current_1m is None:
            self.current_1m = Candle(ts, snapshot.open, snapshot.high, snapshot.low, snapshot.close, snapshot.volume)
            return
        current_ts = self.current_1m.timestamp
        if ts < current_ts:
            return
        if ts == current_ts:
            # The live I1 OHLC is cumulative for the current minute; replace the snapshot.
            self.current_1m = Candle(ts, snapshot.open, snapshot.high, snapshot.low, snapshot.close, snapshot.volume)
            return
        # The old I1 candle is now closed, so add it to the 3-minute builder.
        self.on_minute_closed(self.current_1m)
        self.current_1m = Candle(ts, snapshot.open, snapshot.high, snapshot.low, snapshot.close, snapshot.volume)


class AlertDispatcher:
    """Live-only output: one compact row per confirmed entry signal."""
    def __init__(self):
        self.q: queue.Queue[Optional[EntrySignal]] = queue.Queue()
        self.bot_token = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
        self.chat_id = os.getenv("TELEGRAM_CHAT_ID", "").strip()
        self.log_path = ROOT / "entry_signals.csv"
        self.thread = threading.Thread(target=self._worker, name="signal-alerts", daemon=True)
        self.thread.start()

    def send(self, signal: EntrySignal) -> None:
        self.q.put(signal)

    def _worker(self) -> None:
        while True:
            signal = self.q.get()
            if signal is None:
                self.q.task_done()
                return
            try:
                row = format_signal_row(signal)
                log.info("SIGNAL | %s", row)
                self._append_csv(signal)
                print("\a", end="", flush=True)
                try:
                    import winsound
                    winsound.MessageBeep(winsound.MB_ICONEXCLAMATION)
                except Exception:
                    pass
                print(row, flush=True)
                if self.bot_token and self.chat_id:
                    url = f"https://api.telegram.org/bot{self.bot_token}/sendMessage"
                    try:
                        response = requests.post(
                            url,
                            data={"chat_id": self.chat_id, "text": row},
                            timeout=5,
                        )
                        response.raise_for_status()
                    except Exception as exc:
                        log.error("Telegram alert failed: %s", exc)
            except Exception:
                log.exception("Failed to dispatch signal")
            finally:
                self.q.task_done()

    def _append_csv(self, signal: EntrySignal) -> None:
        new_file = not self.log_path.exists() or self.log_path.stat().st_size == 0
        with self.log_path.open("a", newline="", encoding="utf-8") as file:
            writer = csv.writer(file)
            if new_file:
                writer.writerow(["stock", "signal", "time_ist"])
            writer.writerow([
                signal.symbol,
                signal.direction,
                signal.candle_time.astimezone(IST).strftime("%Y-%m-%d %H:%M"),
            ])


def extract_i1_snapshot(feed: Any) -> Optional[Candle]:
    """Extract current one-minute OHLC from an Upstox V3 full-feed item."""
    plain = object_to_plain(feed)
    full_feed = getv(plain, "fullFeed")
    if full_feed is None:
        return None
    market_ff = getv(full_feed, "marketFF")
    if market_ff is None:
        return None
    market_ohlc = getv(market_ff, "marketOHLC")
    ohlc_items = getv(market_ohlc, "ohlc", []) if market_ohlc is not None else []
    for item in ohlc_items or []:
        interval = str(getv(item, "interval", ""))
        if interval.upper() not in ("I1", "1M", "1MINUTE"):
            continue
        ts_value = getv(item, "ts")
        if ts_value is None:
            continue
        try:
            ts = parse_timestamp(ts_value)
            return Candle(
                timestamp=ts,
                open=float(getv(item, "open")),
                high=float(getv(item, "high")),
                low=float(getv(item, "low")),
                close=float(getv(item, "close")),
                volume=float(getv(item, "vol", getv(item, "volume", 0)) or 0),
            )
        except (TypeError, ValueError, OverflowError):
            continue
    return None


def load_runtime_config() -> tuple[str, dict[str, dict[str, str]]]:
    """Authenticate and resolve the configured stock universe without console chatter."""
    token = os.getenv("UPSTOX_ACCESS_TOKEN", "").strip()
    if not token or token == "PASTE_YOUR_ACCESS_TOKEN_HERE":
        raise RuntimeError("Set UPSTOX_ACCESS_TOKEN in the .env file first. Never share your token.")
    symbols = read_symbols(ROOT / "nifty50_symbols.txt")
    master = load_instrument_master()
    universe = resolve_universe(symbols, master)
    return token, universe


def configured_warmup_days() -> int:
    # The Upstox historical API limits minute history queries to one month.
    try:
        configured = int(os.getenv("WARMUP_CALENDAR_DAYS", "20"))
    except ValueError:
        configured = 20
    return min(25, max(7, configured))


def fetch_universe_history(
    token: str,
    universe: dict[str, dict[str, str]],
    from_date: str,
    to_date: str,
) -> dict[str, list[Candle]]:
    workers = max(1, min(8, int(os.getenv("HISTORICAL_WORKERS", "5"))))
    history: dict[str, list[Candle]] = {}
    failures: list[str] = []
    with ThreadPoolExecutor(max_workers=workers) as pool:
        jobs = {
            pool.submit(fetch_history, sym, item, token, from_date, to_date): sym
            for sym, item in universe.items()
        }
        for future in as_completed(jobs):
            symbol = jobs[future]
            try:
                got_symbol, candles = future.result()
                history[got_symbol] = candles
            except Exception as exc:
                failures.append(symbol)
                log.error("History failed for %s: %s", symbol, exc)
    if failures:
        raise RuntimeError(
            f"History could not be loaded for {len(failures)} stocks: {', '.join(sorted(failures))}. "
            "Check scanner.log and try again; refusing to return an incomplete scan."
        )
    return history


def run_past_mode(target_date: date, token: str, universe: dict[str, dict[str, str]]) -> None:
    """Replay enough history to initialize the engine; print only target-date entries."""
    from_date = (target_date - timedelta(days=configured_warmup_days())).isoformat()
    to_date = target_date.isoformat()
    history = fetch_universe_history(token, universe, from_date, to_date)
    signals: list[EntrySignal] = []
    for symbol, candles in history.items():
        engine = V4SignalEngine(symbol)
        for candle in candles:
            signal = engine.process(candle)
            if signal is not None and candle.timestamp.astimezone(IST).date() == target_date:
                signals.append(signal)

    signals.sort(key=lambda item: (item.candle_time, item.symbol, item.direction))
    if signals:
        print("STOCK | SIGNAL | TIME (IST)")
        for signal in signals:
            print(format_signal_row(signal))
    else:
        print(f"No entry signals found for {target_date.isoformat()}.")


def run_live_mode(token: str, universe: dict[str, dict[str, str]]) -> None:
    """Warm up quietly, then emit only newly confirmed live entry rows."""
    today = datetime.now(IST).date()
    from_date = (today - timedelta(days=configured_warmup_days())).isoformat()
    history = fetch_universe_history(token, universe, from_date, today.isoformat())

    engines: dict[str, V4SignalEngine] = {symbol: V4SignalEngine(symbol) for symbol in universe}
    for symbol, candles in history.items():
        for candle in candles:
            engines[symbol].process(candle)  # Warm-up signals are deliberately suppressed.

    dispatcher = AlertDispatcher()
    aggregators = {symbol: ThreeMinuteAggregator(symbol, engines[symbol], dispatcher.send) for symbol in universe}
    reverse_keys = {item["instrument_key"]: symbol for symbol, item in universe.items()}

    try:
        import upstox_client
    except ImportError as exc:
        raise RuntimeError("Missing Upstox SDK. Run: pip install -r requirements.txt") from exc

    config = upstox_client.Configuration()
    config.access_token = token
    streamer = upstox_client.MarketDataStreamerV3(upstox_client.ApiClient(config))

    def on_open(*_args):
        log.info("WebSocket connected; subscribing to %d stocks", len(universe))
        try:
            streamer.subscribe([item["instrument_key"] for item in universe.values()], "full")
        except Exception:
            log.exception("Subscription failed")

    def on_message(message):
        try:
            plain = object_to_plain(message)
            feeds = getv(plain, "feeds", {}) or {}
            for key, feed in feeds.items():
                symbol = reverse_keys.get(str(key))
                if symbol is None:
                    continue
                snapshot = extract_i1_snapshot(feed)
                if snapshot is not None:
                    aggregators[symbol].on_live_minute_snapshot(snapshot)
        except Exception:
            log.exception("Could not process market-data message")

    def on_error(error):
        log.error("Upstox WebSocket error: %s", error)

    def on_close(*args):
        log.warning("Upstox WebSocket closed; auto-reconnect will keep trying: %s", args)

    def on_reconnecting(*args):
        log.warning("Upstox reconnecting: %s", args)

    def on_auto_reconnect_stopped(*args):
        # This should be extraordinarily unlikely with the large retry budget.
        # If it ever happens, it will be visible in scanner.log instead of
        # looking like a healthy but silent scanner.
        log.critical("Upstox auto-reconnect stopped unexpectedly: %s", args)

    streamer.on("open", on_open)
    streamer.on("message", on_message)
    streamer.on("error", on_error)
    streamer.on("close", on_close)
    streamer.on("reconnecting", on_reconnecting)
    streamer.on("autoReconnectStopped", on_auto_reconnect_stopped)

    # Upstox documents retryCount as the maximum reconnect attempts. The old
    # value (30) could leave the scanner disconnected after a short outage.
    # Use a very high count so live mode keeps retrying until manually stopped.
    # Fail visibly if this SDK version does not support the documented method;
    # silently disabling reconnect would violate the live-scanner requirement.
    try:
        streamer.auto_reconnect(True, RECONNECT_INTERVAL_SECONDS, RECONNECT_RETRY_COUNT)
    except Exception as exc:
        log.exception("Could not configure Upstox WebSocket auto-reconnect")
        raise RuntimeError(
            "Could not configure Upstox auto-reconnect. Update upstox-python-sdk "
            "with: python -m pip install --upgrade upstox-python-sdk"
        ) from exc

    log.info(
        "Live scanner starting: %d stocks; reconnect interval %ds; retry budget %d",
        len(universe), RECONNECT_INTERVAL_SECONDS, RECONNECT_RETRY_COUNT,
    )
    streamer.connect()


def get_cli_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="NIFTY 50 scanner using the user's Pine Trade Engine V4 entry rules."
    )
    parser.add_argument("--mode", choices=["live", "past"], help="live stream or historical scan")
    parser.add_argument("--date", dest="scan_date", help="past scan date in YYYY-MM-DD format")
    args = parser.parse_args()
    if args.mode is None:
        print("Select scanner mode:")
        print("  1. LIVE DATA  - wait silently for new entry signals")
        print("  2. PAST DATA  - scan a date from historical candles")
        selected = input("Choose 1 or 2: ").strip()
        if selected == "1":
            args.mode = "live"
        elif selected == "2":
            args.mode = "past"
        else:
            parser.error("Choose 1 (live) or 2 (past).")
    if args.mode == "past" and not args.scan_date:
        args.scan_date = input("Enter date (YYYY-MM-DD): ").strip()
    return args


def main() -> None:
    args = get_cli_args()
    try:
        target_date = parse_trading_date(args.scan_date) if args.mode == "past" else None
        token, universe = load_runtime_config()
        if args.mode == "past":
            assert target_date is not None
            run_past_mode(target_date, token, universe)
        else:
            run_live_mode(token, universe)
    except (ValueError, RuntimeError, requests.RequestException) as exc:
        raise SystemExit(str(exc)) from exc


if __name__ == "__main__":
    main()
