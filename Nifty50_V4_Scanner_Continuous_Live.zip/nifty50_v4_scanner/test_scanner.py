from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

from scanner import ThreeMinuteAggregator, format_signal_row, parse_trading_date
from strategy_v4 import Candle, EntrySignal, V4SignalEngine

IST = ZoneInfo("Asia/Kolkata")


def test_three_consecutive_minutes_produce_one_three_minute_bar():
    engine = V4SignalEngine("TEST")
    alerts = []
    agg = ThreeMinuteAggregator("TEST", engine, alerts.append)
    start = datetime(2026, 10, 1, 9, 15, tzinfo=IST)
    for i in range(3):
        close = 100 + i
        agg.on_minute_closed(Candle(start + timedelta(minutes=i), close - 0.2, close + 0.5, close - 0.5, close, 100))
    assert len(engine.bars) == 1
    bar = engine.bars[0]
    assert bar.timestamp == start
    assert bar.open == 99.8
    assert bar.high == 102.5
    assert bar.low == 99.5
    assert bar.close == 102


def test_incomplete_three_minute_group_is_skipped():
    engine = V4SignalEngine("TEST")
    alerts = []
    agg = ThreeMinuteAggregator("TEST", engine, alerts.append)
    start = datetime(2026, 10, 1, 9, 15, tzinfo=IST)
    agg.on_minute_closed(Candle(start, 100, 101, 99, 100, 100))
    agg.on_minute_closed(Candle(start + timedelta(minutes=2), 100, 101, 99, 100, 100))
    assert len(engine.bars) == 0


def test_signal_output_contains_only_stock_signal_and_chart_time():
    signal = EntrySignal(
        symbol="ABB",
        direction="LONG ENTRY",
        candle_time=datetime(2026, 10, 1, 9, 33, tzinfo=IST),
        signal_close=123.45,
        stop=120.0,
        target1=126.9,
        target2=130.35,
    )
    assert format_signal_row(signal) == "ABB | LONG ENTRY | 09:33"


def test_parse_past_date_format():
    assert parse_trading_date("2025-01-15").isoformat() == "2025-01-15"


def test_parse_trading_date_rejects_invalid_date_format():
    try:
        parse_trading_date("15-01-2025")
    except ValueError as exc:
        assert "YYYY-MM-DD" in str(exc)
    else:
        raise AssertionError("Invalid date format should be rejected")


def test_configured_universe_contains_50_symbols():
    from pathlib import Path
    from scanner import read_symbols, ROOT

    symbols = read_symbols(ROOT / "nifty50_symbols.txt")
    assert len(symbols) == 50
    assert len(set(symbols)) == 50
    assert "RELIANCE" in symbols
    assert "MAXHEALTH" in symbols


def test_live_mode_uses_effectively_unbounded_reconnect_budget():
    from scanner import RECONNECT_INTERVAL_SECONDS, RECONNECT_RETRY_COUNT

    assert RECONNECT_INTERVAL_SECONDS == 5
    assert RECONNECT_RETRY_COUNT >= 1_000_000_000
